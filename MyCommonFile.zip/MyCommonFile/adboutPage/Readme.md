About Page

2.2.0 - 2013.10.29
-----------------------------
[Added] 增加URL Scheme功能
[Fixed] 修复UITouch传到下一层view的bug