***注意:***
由于NewBlast和AboutPage同时包含UIDevice-Hardware,会导致同时使用这两个组件的时候产生编译错误,解决方法为去掉任意一个UIDevice-Hardware