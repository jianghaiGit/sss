##AnalysisManager

* ##描述

	调用flurry来完成统计功能
* ##调用方式

	[[AnalysisManager sharedManager] startSession];
* ##调用时间

	程序启动后立即调用
* ##注意事项

	无