//
//  MPiAdInterstitialCustomEvent.h
//  MoPub
//
//  Copyright (c) 2013 MoPub. All rights reserved.
//

#import "MPInterstitialCustomEvent.h"
#import <iAd/iAd.h>

@interface MPiAdInterstitialCustomEvent : MPInterstitialCustomEvent <ADInterstitialAdDelegate>

@end
