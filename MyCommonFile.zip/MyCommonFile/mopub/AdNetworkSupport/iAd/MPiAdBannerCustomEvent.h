//
//  MPiAdBannerCustomEvent.h
//  MoPub
//
//  Copyright (c) 2013 MoPub. All rights reserved.
//

#import "MPBannerCustomEvent.h"

@interface MPiAdBannerCustomEvent : MPBannerCustomEvent

@end
